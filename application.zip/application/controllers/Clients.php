<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients extends MY_Controller {

    public function index() {
        require_permission('can_view_client_details');
        $data['clients']    = $this->Client_model->get_all_with_stats();
        $data['page_title'] = 'Clients';
        $this->render('clients/index', $data);
    }

    public function create() {
        require_permission('can_view_client_details');
        $data['timezones']  = timezone_identifiers_list();
        $data['page_title'] = 'Add Client';
        $this->render('clients/create', $data);
    }

    public function store() {
        require_permission('can_view_client_details');
        $this->form_validation->set_rules('company_name',   'Company Name',   'required');
        $this->form_validation->set_rules('contact_person', 'Contact Person', 'required');
        $this->form_validation->set_rules('email',          'Email',          'required|valid_email');

        if ($this->form_validation->run()) {
            $email = $this->input->post('email', TRUE);
            $client_id = $this->Client_model->create([
                'company_name'   => $this->input->post('company_name', TRUE),
                'contact_person' => $this->input->post('contact_person', TRUE),
                'email'          => $email,
                'phone'          => $this->input->post('phone', TRUE),
                'address'        => $this->input->post('address', TRUE),
                'website'        => $this->input->post('website', TRUE),
                'notes'          => $this->input->post('notes', TRUE),
                'created_by'     => $this->current_user->id,
            ]);
            if ($this->db->field_exists('default_timezone', 'clients')) {
                $tz = trim((string)$this->input->post('default_timezone'));
                if ($tz === '' || in_array($tz, timezone_identifiers_list(), true)) {
                    $this->Client_model->update($client_id, ['default_timezone' => $tz === '' ? null : $tz]);
                }
            }

            // Auto-create primary portal login
            $password = $this->input->post('password');
            if ($password) {
                $uid = $this->User_model->create([
                    'role_id'    => 4,
                    'client_id'  => $client_id,
                    'first_name' => $this->input->post('contact_person', TRUE),
                    'last_name'  => '',
                    'email'      => $email,
                    'password'   => password_hash($password, PASSWORD_DEFAULT),
                    'job_title'  => 'Client Contact',
                    'status'     => 'active',
                ]);
                $this->_apply_client_default_tz_to_user($uid, $client_id);
            }

            $this->log_activity('Created client', 'client', $client_id);
            $this->session->set_flashdata('success', 'Client created successfully.');
            redirect('clients/view/' . $client_id);
        } else {
            $this->create();
        }
    }

    public function view($id) {
        require_permission('can_view_client_details');
        $client = $this->Client_model->get($id);
        if (!$client) show_404();
        $data['client']     = $client;
        $data['projects']   = $this->Project_model->get_by_client($id);
        $data['tickets']    = $this->Ticket_model->get_by_client($id);
        $data['users']      = $this->Client_model->get_users($id);
        $data['page_title'] = html_escape($client->company_name);
        $this->render('clients/view', $data);
    }

    public function edit($id) {
        require_permission('can_view_client_details');
        $data['client']     = $this->Client_model->get($id);
        if (!$data['client']) show_404();
        $data['timezones']  = timezone_identifiers_list();
        $data['page_title'] = 'Edit Client';
        $this->render('clients/create', $data);
    }

    public function update($id) {
        require_permission('can_view_client_details');
        $patch = [
            'company_name'   => $this->input->post('company_name', TRUE),
            'contact_person' => $this->input->post('contact_person', TRUE),
            'phone'          => $this->input->post('phone', TRUE),
            'address'        => $this->input->post('address', TRUE),
            'website'        => $this->input->post('website', TRUE),
            'notes'          => $this->input->post('notes', TRUE),
        ];
        if ($this->db->field_exists('default_timezone', 'clients')) {
            $tz = trim((string)$this->input->post('default_timezone'));
            if ($tz === '' || in_array($tz, timezone_identifiers_list(), true)) {
                $patch['default_timezone'] = $tz === '' ? null : $tz;
            }
        }
        $this->Client_model->update($id, $patch);
        $this->session->set_flashdata('success', 'Client updated.');
        redirect('clients/view/' . $id);
    }

    public function delete($id) {
        require_permission('can_view_client_details');
        $this->Client_model->delete($id);
        $this->session->set_flashdata('success', 'Client deleted.');
        redirect('clients');
    }

    public function add_user($client_id) {
        require_permission('can_view_client_details');
        $email = $this->input->post('email', TRUE);
        $pass  = $this->input->post('password');
        if ($this->User_model->email_exists($email)) {
            $this->json_response(['success' => false, 'message' => 'Email already registered.'], 422); return;
        }
        $uid = $this->User_model->create([
            'role_id'    => 4,
            'client_id'  => $client_id,
            'first_name' => $this->input->post('first_name', TRUE),
            'last_name'  => $this->input->post('last_name',  TRUE),
            'email'      => $email,
            'password'   => password_hash($pass, PASSWORD_DEFAULT),
            'job_title'  => $this->input->post('job_title', TRUE) ?: 'Client Contact',
            'status'     => 'active',
        ]);
        $this->_apply_client_default_tz_to_user($uid, $client_id);
        $this->json_response(['success' => true, 'user_id' => $uid, 'message' => 'User added!']);
    }

    private function _apply_client_default_tz_to_user($user_id, $client_id) {
        if (!$this->db->field_exists('timezone', 'users') || !$this->db->field_exists('default_timezone', 'clients')) {
            return;
        }
        $c = $this->Client_model->get($client_id);
        if ($c && !empty($c->default_timezone)) {
            $this->User_model->update($user_id, ['timezone' => $c->default_timezone]);
        }
    }

    public function remove_user($user_id) {
        require_permission('can_view_client_details');
        $this->User_model->delete($user_id);
        $this->json_response(['success' => true]);
    }

    public function reset_password($user_id) {
        require_permission('can_view_client_details');
        $pass = $this->input->post('password');
        if (!$pass || strlen($pass) < 6) {
            $this->json_response(['success' => false, 'message' => 'Min 6 characters.'], 422); return;
        }
        $this->User_model->update($user_id, ['password' => password_hash($pass, PASSWORD_DEFAULT)]);
        $this->json_response(['success' => true, 'message' => 'Password updated.']);
    }
}
