<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_model extends CI_Model {

    public function get($id) {
        return $this->db->get_where('clients', ['id' => $id])->row();
    }

    public function get_all() {
        return $this->db->where('status', 'active')
            ->order_by('company_name')->get('clients')->result();
    }

    public function get_all_with_stats() {
        $clients = $this->db->order_by('company_name')->get('clients')->result();
        foreach ($clients as &$c) {
            $c->project_count = $this->db->where('client_id', $c->id)->count_all_results('projects');
            $c->ticket_count  = $this->db->where('client_id', $c->id)->count_all_results('tickets');
            $c->user_count    = $this->db->where(['client_id' => $c->id, 'role_id' => 4])->count_all_results('users');
        }
        return $clients;
    }

    // Get all client users (portal logins)
    public function get_users($client_id) {
        return $this->db->select('u.*, r.name as role_name')
            ->from('users u')
            ->join('roles r', 'r.id = u.role_id')
            ->where('u.client_id', $client_id)
            ->where('r.slug', 'client')
            ->order_by('u.first_name')
            ->get()->result();
    }

    public function create($data) {
        $this->db->insert('clients', $data);
        return $this->db->insert_id();
    }

    public function update($id, $data) {
        $this->db->where('id', $id)->update('clients', $data);
    }

    public function delete($id) {
        // Remove associated client users first
        $this->db->where('client_id', $id)->delete('users');
        $this->db->delete('clients', ['id' => $id]);
    }

    public function count_all() {
        return $this->db->count_all('clients');
    }
}
